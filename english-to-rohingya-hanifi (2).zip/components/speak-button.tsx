'use client'

import { useState } from 'react'
import { Volume2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import { speak, isTTSSupported } from '@/lib/speech'
import { useSettings } from '@/components/providers/settings-provider'

export function SpeakButton({
  text,
  label = 'Listen',
  className,
  compact = false,
}: {
  text: string
  label?: string
  className?: string
  compact?: boolean
}) {
  const { voiceSpeed } = useSettings()
  const [active, setActive] = useState(false)

  const handle = () => {
    if (!isTTSSupported()) return
    setActive(true)
    speak(text, { rate: voiceSpeed })
    window.setTimeout(() => setActive(false), 900)
  }

  if (compact) {
    return (
      <button
        type="button"
        onClick={handle}
        aria-label={`${label}: ${text}`}
        className={cn(
          'flex size-10 items-center justify-center rounded-full bg-primary/12 text-primary transition-transform active:scale-90',
          active && 'animate-mic-pulse',
          className,
        )}
      >
        <Volume2 className="size-5" />
      </button>
    )
  }

  return (
    <button
      type="button"
      onClick={handle}
      aria-label={`${label}: ${text}`}
      className={cn(
        'inline-flex items-center gap-2 rounded-full bg-primary/12 px-4 py-2 text-sm font-semibold text-primary transition-transform active:scale-95',
        active && 'animate-mic-pulse',
        className,
      )}
    >
      <Volume2 className="size-4" />
      {label}
    </button>
  )
}
