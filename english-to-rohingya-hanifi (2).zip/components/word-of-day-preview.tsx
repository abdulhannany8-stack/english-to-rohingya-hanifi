import Link from 'next/link'
import { Card } from '@/components/ui/card'
import { SpeakButton } from '@/components/speak-button'
import { wordOfTheDay } from '@/lib/data/dictionary'

export function WordOfDayPreview() {
  const word = wordOfTheDay()
  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between gap-4 p-5">
        <div className="min-w-0">
          <p className="text-lg font-bold text-foreground">{word.en}</p>
          <p className="mt-1 font-hanifi text-3xl leading-relaxed text-primary" lang="rhg">
            {word.hanifi}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">{word.roman}</p>
        </div>
        <SpeakButton text={word.en} compact />
      </div>
      <Link
        href="/word"
        className="block border-t border-border/70 bg-muted/40 px-5 py-3 text-center text-sm font-semibold text-primary"
      >
        Open Word of the Day
      </Link>
    </Card>
  )
}
