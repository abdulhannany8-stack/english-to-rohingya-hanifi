'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ChevronLeft, ChevronRight, ArrowLeft, Star } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card } from '@/components/ui/card'
import { Button, buttonVariants } from '@/components/ui/button'
import { SpeakButton } from '@/components/speak-button'
import { useFavorites } from '@/lib/storage'
import { hanifiOf, type Lesson } from '@/lib/data/lessons'

export function LessonPlayer({ lesson }: { lesson: Lesson }) {
  const [index, setIndex] = useState(0)
  const { toggle, isFavorite } = useFavorites()

  const total = lesson.phrases.length
  const phrase = lesson.phrases[index]
  const hanifi = hanifiOf(phrase)
  const progress = Math.round(((index + 1) / total) * 100)
  const fav = isFavorite(phrase.en, 'en-rh')

  const go = (dir: -1 | 1) => {
    setIndex((i) => Math.min(Math.max(i + dir, 0), total - 1))
  }

  return (
    <div className="flex min-h-[70vh] flex-col gap-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Link
          href="/lessons"
          aria-label="Back to lessons"
          className="flex size-10 items-center justify-center rounded-xl bg-muted text-foreground transition-transform active:scale-90"
        >
          <ArrowLeft className="size-5" />
        </Link>
        <div className="min-w-0">
          <h1 className="truncate text-xl font-extrabold tracking-tight">
            {lesson.title}
          </h1>
          <p className="text-xs text-muted-foreground">
            Card {index + 1} of {total}
          </p>
        </div>
      </div>

      {/* Progress */}
      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Flash card */}
      <Card
        key={index}
        className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center animate-in-up"
      >
        <button
          type="button"
          onClick={() =>
            toggle({ en: phrase.en, roman: phrase.roman, hanifi, direction: 'en-rh' })
          }
          aria-label={fav ? 'Remove from favorites' : 'Add to favorites'}
          aria-pressed={fav}
          className="self-end rounded-full p-1.5 transition-transform active:scale-90"
        >
          <Star
            className={cn(
              'size-6',
              fav ? 'fill-accent text-accent' : 'text-muted-foreground',
            )}
          />
        </button>

        <p className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          English
        </p>
        <p className="text-2xl font-extrabold leading-snug text-foreground text-balance">
          {phrase.en}
        </p>

        <div className="my-1 h-px w-16 bg-border" />

        <p className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          Rohingya Hanifi
        </p>
        <p className="font-hanifi text-5xl leading-relaxed text-primary" lang="rhg">
          {hanifi}
        </p>
        <p className="text-lg font-medium text-foreground">{phrase.roman}</p>

        <SpeakButton text={phrase.en} className="mt-2" />
      </Card>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <Button
          variant="outline"
          onClick={() => go(-1)}
          disabled={index === 0}
          className="h-13 flex-1 rounded-2xl py-3.5 text-base font-bold"
        >
          <ChevronLeft className="size-5" />
          Previous
        </Button>
        {index === total - 1 ? (
          <Link
            href="/lessons"
            className={cn(
              buttonVariants({ variant: 'default' }),
              'h-13 flex-1 rounded-2xl py-3.5 text-base font-bold',
            )}
          >
            Finish
          </Link>
        ) : (
          <Button
            onClick={() => go(1)}
            className="h-13 flex-1 rounded-2xl py-3.5 text-base font-bold"
          >
            Next
            <ChevronRight className="size-5" />
          </Button>
        )}
      </div>
    </div>
  )
}
