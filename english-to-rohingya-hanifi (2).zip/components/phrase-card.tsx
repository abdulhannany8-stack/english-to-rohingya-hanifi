'use client'

import { Star } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card } from '@/components/ui/card'
import { SpeakButton } from '@/components/speak-button'
import { useFavorites } from '@/lib/storage'

export function PhraseCard({
  en,
  roman,
  hanifi,
  className,
  showFavorite = true,
}: {
  en: string
  roman: string
  hanifi: string
  className?: string
  showFavorite?: boolean
}) {
  const { isFavorite, toggle } = useFavorites()
  const fav = isFavorite(en, 'en-rh')

  return (
    <Card className={cn('p-4', className)}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="text-base font-semibold text-foreground text-pretty">
            {en}
          </p>
          <p
            className="mt-2 font-hanifi text-2xl leading-relaxed text-primary"
            lang="rhg"
          >
            {hanifi}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">{roman}</p>
        </div>
        {showFavorite && (
          <button
            type="button"
            onClick={() => toggle({ en, roman, hanifi, direction: 'en-rh' })}
            aria-label={fav ? 'Remove from favorites' : 'Add to favorites'}
            aria-pressed={fav}
            className="shrink-0 rounded-full p-2 transition-transform active:scale-90"
          >
            <Star
              className={cn(
                'size-5 transition-colors',
                fav
                  ? 'fill-accent text-accent'
                  : 'text-muted-foreground',
              )}
            />
          </button>
        )}
      </div>
      <div className="mt-3">
        <SpeakButton text={en} />
      </div>
    </Card>
  )
}
