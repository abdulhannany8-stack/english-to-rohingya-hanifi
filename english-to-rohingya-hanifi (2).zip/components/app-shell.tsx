'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Menu, X, Moon, Sun, Languages } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { useSettings } from '@/components/providers/settings-provider'
import { menuItems, bottomNav } from '@/lib/nav'

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [menuOpen, setMenuOpen] = useState(false)
  const { resolvedTheme, setTheme } = useSettings()

  // Close menu on route change
  useEffect(() => {
    setMenuOpen(false)
  }, [pathname])

  // Lock scroll when menu open
  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [menuOpen])

  const toggleTheme = () =>
    setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border/70 bg-background/85 px-3 backdrop-blur-md">
        <Button
          variant="ghost"
          size="icon-lg"
          aria-label="Open menu"
          onClick={() => setMenuOpen(true)}
          className="rounded-xl"
        >
          <Menu className="size-6" />
        </Button>

        <Link href="/" className="flex items-center gap-2">
          <span className="flex size-8 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Languages className="size-5" />
          </span>
          <span className="text-base font-bold tracking-tight text-foreground">
            Rohingya Hanifi
          </span>
        </Link>

        <Button
          variant="ghost"
          size="icon-lg"
          aria-label="Toggle dark mode"
          onClick={toggleTheme}
          className="rounded-xl"
        >
          {resolvedTheme === 'dark' ? (
            <Sun className="size-6" />
          ) : (
            <Moon className="size-6" />
          )}
        </Button>
      </header>

      {/* Main content */}
      <main className="flex-1 px-4 pt-4 pb-28">{children}</main>

      {/* Bottom navigation */}
      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto max-w-md border-t border-border/70 bg-background/90 backdrop-blur-md">
        <ul className="flex items-stretch justify-around px-2 py-1.5">
          {bottomNav.map((item) => {
            const active =
              item.href === '/'
                ? pathname === '/'
                : pathname.startsWith(item.href)
            const Icon = item.icon
            return (
              <li key={item.href} className="flex-1">
                <Link
                  href={item.href}
                  className={cn(
                    'flex flex-col items-center gap-0.5 rounded-xl py-1.5 text-[11px] font-medium transition-colors',
                    active
                      ? 'text-primary'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  <span
                    className={cn(
                      'flex size-9 items-center justify-center rounded-xl transition-colors',
                      active && 'bg-primary/12',
                    )}
                  >
                    <Icon className="size-5" />
                  </span>
                  {item.label}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Slide-out menu */}
      <div
        className={cn(
          'fixed inset-0 z-40 transition-opacity duration-300',
          menuOpen ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-0',
        )}
      >
        <div
          className="absolute inset-0 bg-foreground/40 backdrop-blur-[2px]"
          onClick={() => setMenuOpen(false)}
          aria-hidden
        />
        <aside
          className={cn(
            'absolute inset-y-0 left-0 flex w-72 max-w-[82%] flex-col bg-card shadow-2xl transition-transform duration-300 ease-out',
            menuOpen ? 'translate-x-0' : '-translate-x-full',
          )}
          role="dialog"
          aria-label="Navigation menu"
        >
          <div className="flex items-center justify-between border-b border-border/70 px-4 py-4">
            <div className="flex items-center gap-2">
              <span className="flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <Languages className="size-5" />
              </span>
              <div className="leading-tight">
                <p className="text-sm font-bold text-foreground">Menu</p>
                <p className="text-xs text-muted-foreground">
                  English → Rohingya Hanifi
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Close menu"
              onClick={() => setMenuOpen(false)}
              className="rounded-lg"
            >
              <X className="size-5" />
            </Button>
          </div>

          <nav className="flex-1 overflow-y-auto p-2">
            <ul className="flex flex-col gap-0.5">
              {menuItems.map((item) => {
                const active =
                  item.href === '/'
                    ? pathname === '/'
                    : pathname.startsWith(item.href)
                const Icon = item.icon
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={cn(
                        'flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition-colors',
                        active
                          ? 'bg-primary/12 text-primary'
                          : 'text-foreground hover:bg-muted',
                      )}
                    >
                      <Icon className="size-5 shrink-0" />
                      {item.label}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </nav>

          <div className="border-t border-border/70 px-4 py-3">
            <p className="text-xs text-muted-foreground">
              Created by{' '}
              <span className="font-semibold text-foreground">Arakani Gamer</span>
            </p>
          </div>
        </aside>
      </div>
    </div>
  )
}
