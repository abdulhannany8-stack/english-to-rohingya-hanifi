'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'

export type Theme = 'light' | 'dark' | 'system'

export type Settings = {
  theme: Theme
  textScale: number
  voiceSpeed: number
}

const DEFAULTS: Settings = {
  theme: 'system',
  textScale: 1,
  voiceSpeed: 1,
}

const STORAGE_KEY = 'erh-settings'

type SettingsContextValue = Settings & {
  setTheme: (theme: Theme) => void
  setTextScale: (scale: number) => void
  setVoiceSpeed: (speed: number) => void
  resolvedTheme: 'light' | 'dark'
}

const SettingsContext = createContext<SettingsContextValue | null>(null)

function applyTheme(theme: Theme) {
  if (typeof document === 'undefined') return
  const isDark =
    theme === 'dark' ||
    (theme === 'system' &&
      window.matchMedia('(prefers-color-scheme: dark)').matches)
  const root = document.documentElement
  root.classList.toggle('dark', isDark)
  root.classList.toggle('light', !isDark)
}

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<Settings>(DEFAULTS)
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('light')

  // Load persisted settings on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw)
        setSettings({ ...DEFAULTS, ...parsed })
      }
    } catch {
      // ignore
    }
  }, [])

  // Persist + apply on change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings))
    } catch {
      // ignore
    }
    applyTheme(settings.theme)
    document.documentElement.style.setProperty(
      '--text-scale',
      String(settings.textScale),
    )
    const isDark =
      settings.theme === 'dark' ||
      (settings.theme === 'system' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches)
    setResolvedTheme(isDark ? 'dark' : 'light')
  }, [settings])

  // React to OS theme changes when in system mode
  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    const handler = () => {
      if (settings.theme === 'system') {
        applyTheme('system')
        setResolvedTheme(mq.matches ? 'dark' : 'light')
      }
    }
    mq.addEventListener('change', handler)
    return () => mq.removeEventListener('change', handler)
  }, [settings.theme])

  const setTheme = useCallback((theme: Theme) => {
    setSettings((s) => ({ ...s, theme }))
  }, [])
  const setTextScale = useCallback((textScale: number) => {
    setSettings((s) => ({ ...s, textScale }))
  }, [])
  const setVoiceSpeed = useCallback((voiceSpeed: number) => {
    setSettings((s) => ({ ...s, voiceSpeed }))
  }, [])

  const value = useMemo<SettingsContextValue>(
    () => ({
      ...settings,
      resolvedTheme,
      setTheme,
      setTextScale,
      setVoiceSpeed,
    }),
    [settings, resolvedTheme, setTheme, setTextScale, setVoiceSpeed],
  )

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const ctx = useContext(SettingsContext)
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider')
  return ctx
}
