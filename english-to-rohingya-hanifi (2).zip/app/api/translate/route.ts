import { generateText } from 'ai'
import { NextResponse } from 'next/server'
import { toHanifi } from '@/lib/hanifi'
import { localLookup } from '@/lib/data/dictionary'

export const runtime = 'nodejs'
export const maxDuration = 30

type Body = {
  text?: string
  direction?: 'en-rh' | 'rh-en'
}

// The AI Gateway model used for translation. Runs only on the server,
// so no API keys are ever exposed to the Android client.
const MODEL = 'openai/gpt-4o-mini'

export async function POST(req: Request) {
  let body: Body
  try {
    body = (await req.json()) as Body
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }

  const text = (body.text ?? '').trim()
  const direction = body.direction === 'rh-en' ? 'rh-en' : 'en-rh'

  if (!text) {
    return NextResponse.json({ error: 'No text provided.' }, { status: 400 })
  }
  if (text.length > 500) {
    return NextResponse.json(
      { error: 'Text is too long (max 500 characters).' },
      { status: 400 },
    )
  }

  // 1) Fast offline path for known single words/phrases (en -> rohingya).
  if (direction === 'en-rh') {
    const hit = localLookup(text)
    if (hit) {
      return NextResponse.json({
        en: hit.en,
        roman: hit.roman,
        hanifi: hit.hanifi,
        source: 'dictionary',
      })
    }
  }

  // 2) AI Gateway translation.
  try {
    const system =
      direction === 'en-rh'
        ? `You are a translator from English to the Rohingya language.
Return ONLY a compact JSON object with two string fields:
"roman" = the Rohingya translation written in Rohingyalish (Latin Rohingya script),
"en" = the original English text.
Do not add explanations. Keep it natural and simple.`
        : `You are a translator from the Rohingya language (given in Rohingyalish, Latin Rohingya) to English.
Return ONLY a compact JSON object with two string fields:
"en" = the English translation,
"roman" = the original Rohingya (Rohingyalish) text.
Do not add explanations.`

    const { text: raw } = await generateText({
      model: MODEL,
      system,
      prompt: text,
      temperature: 0.2,
    })

    const jsonMatch = raw.match(/\{[\s\S]*\}/)
    let parsed: { en?: string; roman?: string } = {}
    if (jsonMatch) {
      try {
        parsed = JSON.parse(jsonMatch[0])
      } catch {
        // fall through
      }
    }

    const roman = parsed.roman?.trim() || (direction === 'rh-en' ? text : raw.trim())
    const en = parsed.en?.trim() || (direction === 'en-rh' ? text : raw.trim())

    return NextResponse.json({
      en,
      roman,
      hanifi: toHanifi(roman),
      source: 'ai',
    })
  } catch (err) {
    console.log('[v0] translate error:', err instanceof Error ? err.message : err)
    return NextResponse.json(
      {
        error:
          'Translation service is unavailable right now. Please try again in a moment.',
      },
      { status: 502 },
    )
  }
}
