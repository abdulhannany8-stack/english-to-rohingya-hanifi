'use client'

import { useRef, useState } from 'react'
import {
  ArrowRightLeft,
  Copy,
  Check,
  Eraser,
  Star,
  Mic,
  Loader2,
  Sparkles,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { SpeakButton } from '@/components/speak-button'
import { useFavorites, useHistory } from '@/lib/storage'
import { listen, isSTTSupported } from '@/lib/speech'

type Direction = 'en-rh' | 'rh-en'

type Result = {
  en: string
  roman: string
  hanifi: string
}

export default function TranslatorPage() {
  const [direction, setDirection] = useState<Direction>('en-rh')
  const [input, setInput] = useState('')
  const [result, setResult] = useState<Result | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [listening, setListening] = useState(false)
  const stopRef = useRef<(() => void) | null>(null)

  const { add: addHistory } = useHistory()
  const { toggle, isFavorite } = useFavorites()

  const sourceIsEnglish = direction === 'en-rh'
  const saved = result ? isFavorite(result.en, direction) : false

  async function handleTranslate() {
    const text = input.trim()
    if (!text || loading) return
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, direction }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error ?? 'Something went wrong.')
        return
      }
      const r: Result = { en: data.en, roman: data.roman, hanifi: data.hanifi }
      setResult(r)
      addHistory({ ...r, direction })
    } catch {
      setError('Network error. Please check your connection.')
    } finally {
      setLoading(false)
    }
  }

  function handleSwap() {
    setDirection((d) => (d === 'en-rh' ? 'rh-en' : 'en-rh'))
    // Move a result back into the input for chained translation
    if (result) {
      setInput(sourceIsEnglish ? result.roman : result.en)
    }
    setResult(null)
    setError(null)
  }

  function handleClear() {
    setInput('')
    setResult(null)
    setError(null)
  }

  async function handleCopy() {
    if (!result) return
    const toCopy = `${result.en}\n${result.hanifi}\n${result.roman}`
    try {
      await navigator.clipboard.writeText(toCopy)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1500)
    } catch {
      // ignore
    }
  }

  function handleSave() {
    if (!result) return
    toggle({ ...result, direction })
  }

  function handleMic() {
    if (listening) {
      stopRef.current?.()
      setListening(false)
      return
    }
    const stop = listen({
      lang: sourceIsEnglish ? 'en-US' : 'en-US',
      onResult: (t) => setInput((prev) => (prev ? `${prev} ${t}` : t)),
      onEnd: () => setListening(false),
      onError: () => setListening(false),
    })
    if (stop) {
      stopRef.current = stop
      setListening(true)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <header className="animate-in-up">
        <h1 className="text-2xl font-extrabold tracking-tight">Translator</h1>
        <p className="text-sm text-muted-foreground">
          Translate between English and Rohingya Hanifi.
        </p>
      </header>

      {/* Direction switch */}
      <Card className="flex items-center justify-between gap-2 p-3 animate-in-up">
        <div className="flex-1 rounded-2xl bg-muted/60 py-2.5 text-center">
          <p className="text-xs font-medium text-muted-foreground">From</p>
          <p className="font-bold text-foreground">
            {sourceIsEnglish ? 'English' : 'Rohingya'}
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon-lg"
          aria-label="Swap languages"
          onClick={handleSwap}
          className="shrink-0 rounded-2xl bg-primary/12 text-primary"
        >
          <ArrowRightLeft className="size-5" />
        </Button>
        <div className="flex-1 rounded-2xl bg-muted/60 py-2.5 text-center">
          <p className="text-xs font-medium text-muted-foreground">To</p>
          <p className="font-bold text-foreground">
            {sourceIsEnglish ? 'Rohingya' : 'English'}
          </p>
        </div>
      </Card>

      {/* Input */}
      <Card className="p-4 animate-in-up">
        <label htmlFor="translate-input" className="sr-only">
          Text to translate
        </label>
        <textarea
          id="translate-input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (
              e.key === 'Enter' &&
              (e.metaKey || e.ctrlKey) &&
              !e.nativeEvent.isComposing
            ) {
              e.preventDefault()
              handleTranslate()
            }
          }}
          maxLength={500}
          rows={3}
          placeholder={
            sourceIsEnglish
              ? 'Type English text, e.g. "How are you?"'
              : 'Type Rohingya (Rohingyalish), e.g. "Kemon aso?"'
          }
          className="w-full resize-none bg-transparent text-lg leading-relaxed text-foreground outline-none placeholder:text-muted-foreground/70"
        />
        <div className="mt-2 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {input.length}/500
          </span>
          <div className="flex items-center gap-2">
            {isSTTSupported() && (
              <Button
                variant="ghost"
                size="icon"
                aria-label={listening ? 'Stop voice input' : 'Start voice input'}
                onClick={handleMic}
                className={cn(
                  'rounded-full',
                  listening
                    ? 'animate-mic-pulse bg-destructive/15 text-destructive'
                    : 'bg-primary/12 text-primary',
                )}
              >
                <Mic className="size-5" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              aria-label="Clear text"
              onClick={handleClear}
              disabled={!input && !result}
              className="rounded-full"
            >
              <Eraser className="size-5" />
            </Button>
          </div>
        </div>
      </Card>

      {/* Translate button */}
      <Button
        onClick={handleTranslate}
        disabled={!input.trim() || loading}
        className="h-14 rounded-2xl text-base font-bold animate-in-up"
      >
        {loading ? (
          <Loader2 className="size-5 animate-spin" />
        ) : (
          <Sparkles className="size-5" />
        )}
        {loading ? 'Translating…' : 'Translate'}
      </Button>

      {error && (
        <Card className="border-destructive/40 bg-destructive/10 p-4 text-sm font-medium text-destructive">
          {error}
        </Card>
      )}

      {/* Result */}
      {result && (
        <Card className="p-5 animate-in-up">
          <div className="flex items-start justify-between gap-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {sourceIsEnglish ? 'Rohingya Hanifi' : 'English'}
            </p>
            <SpeakButton
              text={result.en}
              label="Listen"
              compact
            />
          </div>

          {sourceIsEnglish ? (
            <>
              <p
                className="mt-3 font-hanifi text-4xl leading-relaxed text-primary"
                lang="rhg"
              >
                {result.hanifi}
              </p>
              <p className="mt-2 text-lg font-medium text-foreground">
                {result.roman}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{result.en}</p>
            </>
          ) : (
            <>
              <p className="mt-3 text-3xl font-bold leading-snug text-foreground">
                {result.en}
              </p>
              <p
                className="mt-2 font-hanifi text-2xl leading-relaxed text-primary"
                lang="rhg"
              >
                {result.hanifi}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                {result.roman}
              </p>
            </>
          )}

          {/* Result actions */}
          <div className="mt-5 grid grid-cols-2 gap-2.5">
            <Button
              variant="outline"
              onClick={handleCopy}
              className="h-11 rounded-xl font-semibold"
            >
              {copied ? (
                <Check className="size-4 text-primary" />
              ) : (
                <Copy className="size-4" />
              )}
              {copied ? 'Copied' : 'Copy'}
            </Button>
            <Button
              variant={saved ? 'secondary' : 'outline'}
              onClick={handleSave}
              className="h-11 rounded-xl font-semibold"
            >
              <Star
                className={cn('size-4', saved && 'fill-accent text-accent')}
              />
              {saved ? 'Saved' : 'Save'}
            </Button>
          </div>
        </Card>
      )}
    </div>
  )
}
