import Link from 'next/link'
import {
  Languages,
  BookOpen,
  Mic,
  CalendarDays,
  Star,
  History,
  ArrowRight,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { WordOfDayPreview } from '@/components/word-of-day-preview'
import { lessons } from '@/lib/data/lessons'

const quickActions = [
  { label: 'Translator', href: '/translator', icon: Languages, hint: 'EN ↔ Rohingya' },
  { label: 'Lessons', href: '/lessons', icon: BookOpen, hint: '10 topics' },
  { label: 'Voice Practice', href: '/voice', icon: Mic, hint: 'Speak & listen' },
  { label: 'Word of the Day', href: '/word', icon: CalendarDays, hint: 'Learn daily' },
  { label: 'Favorites', href: '/favorites', icon: Star, hint: 'Saved words' },
  { label: 'History', href: '/history', icon: History, hint: 'Recent' },
]

export default function HomePage() {
  return (
    <div className="flex flex-col gap-6">
      {/* Hero */}
      <section className="animate-in-up">
        <div className="relative overflow-hidden rounded-3xl bg-primary p-6 text-primary-foreground shadow-md">
          <div className="relative z-10">
            <p className="text-xs font-semibold uppercase tracking-widest text-primary-foreground/80">
              English to Rohingya Hanifi
            </p>
            <h1 className="mt-2 text-2xl font-extrabold leading-tight text-balance">
              Learn English Through Rohingya Hanifi
            </h1>
            <p className="mt-2 max-w-[85%] text-sm text-primary-foreground/85 text-pretty">
              Translate, listen and learn with your own language and writing
              system.
            </p>
            <Link
              href="/translator"
              className="mt-4 inline-flex items-center gap-2 rounded-full bg-background px-4 py-2.5 text-sm font-bold text-primary transition-transform active:scale-95"
            >
              Start translating
              <ArrowRight className="size-4" />
            </Link>
          </div>
          <span
            aria-hidden
            className="pointer-events-none absolute -right-6 -top-8 font-hanifi text-[7rem] leading-none text-primary-foreground/15"
          >
            {'\u{10D00}\u{10D18}'}
          </span>
        </div>
      </section>

      {/* Quick actions */}
      <section className="animate-in-up" style={{ animationDelay: '60ms' }}>
        <h2 className="mb-3 px-1 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Quick actions
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {quickActions.map((a) => {
            const Icon = a.icon
            return (
              <Link key={a.href} href={a.href}>
                <Card className="flex h-full flex-col gap-3 p-4 transition-transform active:scale-[0.98]">
                  <span className="flex size-11 items-center justify-center rounded-2xl bg-primary/12 text-primary">
                    <Icon className="size-6" />
                  </span>
                  <div>
                    <p className="font-bold text-foreground">{a.label}</p>
                    <p className="text-xs text-muted-foreground">{a.hint}</p>
                  </div>
                </Card>
              </Link>
            )
          })}
        </div>
      </section>

      {/* Word of the day */}
      <section className="animate-in-up" style={{ animationDelay: '120ms' }}>
        <h2 className="mb-3 px-1 text-sm font-bold uppercase tracking-wide text-muted-foreground">
          Word of the Day
        </h2>
        <WordOfDayPreview />
      </section>

      {/* Lessons preview */}
      <section className="animate-in-up" style={{ animationDelay: '180ms' }}>
        <div className="mb-3 flex items-center justify-between px-1">
          <h2 className="text-sm font-bold uppercase tracking-wide text-muted-foreground">
            Popular Lessons
          </h2>
          <Link
            href="/lessons"
            className="text-sm font-semibold text-primary"
          >
            See all
          </Link>
        </div>
        <div className="flex flex-col gap-2.5">
          {lessons.slice(0, 4).map((l) => (
            <Link key={l.id} href={`/lessons/${l.id}`}>
              <Card className="flex items-center justify-between p-4 transition-transform active:scale-[0.98]">
                <div className="flex items-center gap-3">
                  <span className="flex size-10 items-center justify-center rounded-2xl bg-accent/25 text-lg font-bold text-accent-foreground">
                    {l.title.charAt(0)}
                  </span>
                  <div>
                    <p className="font-bold text-foreground">{l.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {l.phrases.length} phrases
                    </p>
                  </div>
                </div>
                <ArrowRight className="size-5 text-muted-foreground" />
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <footer className="pb-2 pt-2 text-center">
        <p className="text-xs text-muted-foreground">
          Created by{' '}
          <span className="font-semibold text-foreground">Arakani Gamer</span>
        </p>
      </footer>
    </div>
  )
}
