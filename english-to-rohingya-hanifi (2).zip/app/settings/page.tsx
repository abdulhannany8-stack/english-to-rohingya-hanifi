'use client'

import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { SpeakButton } from '@/components/speak-button'
import { useSettings, type Theme } from '@/components/providers/settings-provider'
import { Sun, Moon, Monitor, Type, Volume2 } from 'lucide-react'
import { cn } from '@/lib/utils'

const themeOptions: { value: Theme; label: string; icon: typeof Sun }[] = [
  { value: 'light', label: 'Light', icon: Sun },
  { value: 'dark', label: 'Dark', icon: Moon },
  { value: 'system', label: 'System', icon: Monitor },
]

const textSizes = [
  { value: 0.9, label: 'Small' },
  { value: 1, label: 'Default' },
  { value: 1.15, label: 'Large' },
  { value: 1.3, label: 'Extra' },
]

const speeds = [
  { value: 0.7, label: 'Slow' },
  { value: 1, label: 'Normal' },
  { value: 1.3, label: 'Fast' },
]

export default function SettingsPage() {
  const { theme, setTheme, textScale, setTextScale, voiceSpeed, setVoiceSpeed } = useSettings()

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <header className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="mt-1 text-muted-foreground">Personalize your experience.</p>
      </header>

      <div className="flex flex-col gap-4">
        {/* Theme */}
        <Card className="p-5">
          <h2 className="mb-1 text-lg font-semibold">Appearance</h2>
          <p className="mb-4 text-sm text-muted-foreground">Choose light, dark, or match your device.</p>
          <div className="grid grid-cols-3 gap-2.5">
            {themeOptions.map((opt) => {
              const active = theme === opt.value
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setTheme(opt.value)}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-2xl border-2 p-4 transition-all',
                    active
                      ? 'border-primary bg-primary/10 text-primary'
                      : 'border-border text-muted-foreground hover:border-primary/40',
                  )}
                  aria-pressed={active}
                >
                  <opt.icon className="size-6" />
                  <span className="text-sm font-medium">{opt.label}</span>
                </button>
              )
            })}
          </div>
        </Card>

        {/* Text size */}
        <Card className="p-5">
          <div className="mb-1 flex items-center gap-2">
            <Type className="size-5 text-primary" />
            <h2 className="text-lg font-semibold">Text Size</h2>
          </div>
          <p className="mb-4 text-sm text-muted-foreground">Make reading more comfortable.</p>
          <div className="grid grid-cols-4 gap-2">
            {textSizes.map((s) => (
              <button
                key={s.value}
                type="button"
                onClick={() => setTextScale(s.value)}
                className={cn(
                  'rounded-xl border-2 py-2.5 text-center text-sm font-medium transition-all',
                  Math.abs(textScale - s.value) < 0.01
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/40',
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
          <p className="mt-4 rounded-xl bg-muted/50 p-3 text-center" style={{ fontSize: `${textScale}rem` }}>
            Preview text sample
          </p>
        </Card>

        {/* Voice speed */}
        <Card className="p-5">
          <div className="mb-1 flex items-center gap-2">
            <Volume2 className="size-5 text-primary" />
            <h2 className="text-lg font-semibold">Voice Speed</h2>
          </div>
          <p className="mb-4 text-sm text-muted-foreground">How fast English is spoken aloud.</p>
          <div className="grid grid-cols-3 gap-2">
            {speeds.map((s) => (
              <button
                key={s.value}
                type="button"
                onClick={() => setVoiceSpeed(s.value)}
                className={cn(
                  'rounded-xl border-2 py-2.5 text-center text-sm font-medium transition-all',
                  Math.abs(voiceSpeed - s.value) < 0.01
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/40',
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
          <div className="mt-4 flex justify-center">
            <SpeakButton text="Hello, this is a voice test." label="Test voice" />
          </div>
        </Card>
      </div>
    </div>
  )
}
