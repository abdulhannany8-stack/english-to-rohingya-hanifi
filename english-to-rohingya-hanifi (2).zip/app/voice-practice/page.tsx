'use client'

import { useMemo, useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { SpeakButton } from '@/components/speak-button'
import { lessons, hanifiOf } from '@/lib/data/lessons'
import { listen, isSTTSupported } from '@/lib/speech'
import { Mic, MicOff, RefreshCw, Check, X } from 'lucide-react'

function normalize(s: string) {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
}

// Flatten a curated set of practice phrases from the lessons (skip number list).
const PRACTICE = lessons
  .filter((l) => l.id !== 'numbers')
  .flatMap((l) => l.phrases.map((p) => ({ ...p, lesson: l.title })))
  .filter((p) => /^[a-zA-Z0-9 ,.'?!-]+$/.test(p.en))

export default function VoicePracticePage() {
  const supported = isSTTSupported()
  const [index, setIndex] = useState(0)
  const [listening, setListening] = useState(false)
  const [heard, setHeard] = useState('')
  const [result, setResult] = useState<'correct' | 'wrong' | null>(null)

  const current = PRACTICE[index]
  const progress = useMemo(() => Math.round(((index + 1) / PRACTICE.length) * 100), [index])

  function next() {
    setHeard('')
    setResult(null)
    setIndex((i) => (i + 1) % PRACTICE.length)
  }

  function startListening() {
    setHeard('')
    setResult(null)
    const stop = listen({
      lang: 'en-US',
      onResult: (transcript) => {
        setHeard(transcript)
        const ok = normalize(transcript) === normalize(current.en)
        setResult(ok ? 'correct' : 'wrong')
      },
      onEnd: () => setListening(false),
      onError: () => setListening(false),
    })
    if (stop) setListening(true)
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <header className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Voice Practice</h1>
        <p className="mt-1 text-muted-foreground">Listen, then say the English phrase out loud.</p>
      </header>

      <div className="mb-4 h-2 overflow-hidden rounded-full bg-secondary">
        <div className="h-full rounded-full bg-primary transition-all duration-500" style={{ width: `${progress}%` }} />
      </div>
      <p className="mb-4 text-sm text-muted-foreground">
        Phrase {index + 1} of {PRACTICE.length} · {current.lesson}
      </p>

      <Card className="animate-fade-in-up p-6 text-center">
        <p className="text-sm font-medium uppercase tracking-wide text-muted-foreground">Say this</p>
        <p className="mt-3 text-balance text-3xl font-bold leading-tight">{current.en}</p>
        <p className="mt-2 font-hanifi text-2xl text-primary" dir="rtl">
          {hanifiOf(current)}
        </p>
        <div className="mt-4 flex justify-center">
          <SpeakButton text={current.en} label="Listen" />
        </div>
      </Card>

      {result && (
        <Card
          className={`mt-4 animate-fade-in-up p-4 ${
            result === 'correct' ? 'border-2 border-primary' : 'border-2 border-destructive'
          }`}
        >
          <div className="flex items-center gap-2">
            {result === 'correct' ? (
              <Check className="size-5 text-primary" />
            ) : (
              <X className="size-5 text-destructive" />
            )}
            <p className="font-semibold">{result === 'correct' ? 'Correct! Well done.' : 'Not quite — try again.'}</p>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">You said: “{heard}”</p>
        </Card>
      )}

      <div className="mt-6 flex items-center justify-center gap-3">
        {supported ? (
          <Button size="lg" onClick={startListening} disabled={listening} className="min-w-40">
            {listening ? <MicOff className="mr-2 size-5 animate-pulse" /> : <Mic className="mr-2 size-5" />}
            {listening ? 'Listening…' : 'Speak'}
          </Button>
        ) : (
          <Card className="p-3 text-center text-sm text-muted-foreground">
            Voice recognition is not supported in this browser. Try Chrome on Android.
          </Card>
        )}
        <Button size="lg" variant="outline" onClick={next}>
          <RefreshCw className="mr-2 size-5" />
          Next
        </Button>
      </div>
    </div>
  )
}
