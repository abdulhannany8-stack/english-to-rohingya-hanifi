'use client'

import { useMemo, useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { SpeakButton } from '@/components/speak-button'
import { wordOfTheDay, wordOfTheDayPool, type Entry } from '@/lib/data/dictionary'
import { useFavorites } from '@/lib/storage'
import { Star, Shuffle, CalendarDays } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function WordOfDayPage() {
  const today = useMemo(() => wordOfTheDay(), [])
  const [word, setWord] = useState<Entry>(today)
  const [isToday, setIsToday] = useState(true)
  const { toggle, isFavorite } = useFavorites()

  const fav = isFavorite(word.en, 'en-rh')

  function shuffle() {
    const pool = wordOfTheDayPool
    let next = word
    while (next.en === word.en && pool.length > 1) {
      next = pool[Math.floor(Math.random() * pool.length)]
    }
    setWord(next)
    setIsToday(next.en === today.en)
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <header className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Word of the Day</h1>
        <p className="mt-1 text-muted-foreground">Learn one new word every day.</p>
      </header>

      <Card className="animate-fade-in-up overflow-hidden">
        <div className="flex items-center gap-2 border-b border-border/60 bg-primary/10 px-5 py-3 text-primary">
          <CalendarDays className="size-4" />
          <span className="text-sm font-semibold">
            {isToday
              ? new Date().toLocaleDateString(undefined, {
                  weekday: 'long',
                  month: 'long',
                  day: 'numeric',
                })
              : 'Random word'}
          </span>
        </div>
        <div className="px-6 py-8 text-center">
          <p className="text-3xl font-bold">{word.en}</p>
          <p className="mt-4 font-hanifi text-5xl leading-relaxed text-primary" dir="rtl">
            {word.hanifi}
          </p>
          <p className="mt-3 text-lg text-muted-foreground">{word.roman}</p>
          <div className="mt-6 flex justify-center">
            <SpeakButton text={word.en} label="Listen" />
          </div>
        </div>
      </Card>

      <div className="mt-6 flex gap-3">
        <Button variant="outline" size="lg" className="flex-1" onClick={shuffle}>
          <Shuffle className="mr-2 size-5" />
          Another word
        </Button>
        <Button
          variant={fav ? 'default' : 'outline'}
          size="lg"
          className="flex-1"
          onClick={() => toggle({ ...word, direction: 'en-rh' })}
        >
          <Star className={cn('mr-2 size-5', fav && 'fill-current')} />
          {fav ? 'Saved' : 'Save'}
        </Button>
      </div>
    </div>
  )
}
