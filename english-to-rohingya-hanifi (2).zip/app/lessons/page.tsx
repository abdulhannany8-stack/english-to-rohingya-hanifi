import Link from 'next/link'
import {
  HandHeart,
  UserRound,
  Hash,
  Users,
  Utensils,
  GraduationCap,
  House,
  Sun,
  CircleHelp,
  MessagesSquare,
  ChevronRight,
  type LucideIcon,
} from 'lucide-react'
import { Card } from '@/components/ui/card'
import { lessons } from '@/lib/data/lessons'

const iconMap: Record<string, LucideIcon> = {
  HandHeart,
  UserRound,
  Hash,
  Users,
  Utensils,
  GraduationCap,
  House,
  Sun,
  CircleHelp,
  MessagesSquare,
}

export default function LessonsPage() {
  return (
    <div className="flex flex-col gap-4">
      <header className="animate-in-up">
        <h1 className="text-2xl font-extrabold tracking-tight">Lessons</h1>
        <p className="text-sm text-muted-foreground">
          Learn English step by step through Rohingya Hanifi.
        </p>
      </header>

      <div className="flex flex-col gap-3">
        {lessons.map((lesson, i) => {
          const Icon = iconMap[lesson.icon] ?? HandHeart
          return (
            <Link
              key={lesson.id}
              href={`/lessons/${lesson.id}`}
              className="animate-in-up"
              style={{ animationDelay: `${i * 40}ms` }}
            >
              <Card className="flex items-center gap-4 p-4 transition-transform active:scale-[0.98]">
                <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-primary/12 text-primary">
                  <Icon className="size-6" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-muted-foreground">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <p className="truncate font-bold text-foreground">
                      {lesson.title}
                    </p>
                  </div>
                  <p className="truncate text-sm text-muted-foreground">
                    {lesson.description}
                  </p>
                </div>
                <ChevronRight className="size-5 shrink-0 text-muted-foreground" />
              </Card>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
