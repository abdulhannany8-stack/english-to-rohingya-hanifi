import { notFound } from 'next/navigation'
import { getLesson, lessons } from '@/lib/data/lessons'
import { LessonPlayer } from '@/components/lesson-player'

export function generateStaticParams() {
  return lessons.map((l) => ({ id: l.id }))
}

export default async function LessonDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const lesson = getLesson(id)
  if (!lesson) notFound()
  return <LessonPlayer lesson={lesson} />
}
