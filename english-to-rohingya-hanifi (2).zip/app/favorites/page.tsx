'use client'

import Link from 'next/link'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { SpeakButton } from '@/components/speak-button'
import { useFavorites } from '@/lib/storage'
import { Star, Trash2, ArrowRight } from 'lucide-react'

export default function FavoritesPage() {
  const { favorites, remove, clear } = useFavorites()

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Favorites</h1>
          <p className="mt-1 text-muted-foreground">Your saved words and phrases.</p>
        </div>
        {favorites.length > 0 && (
          <Button variant="ghost" size="sm" onClick={clear} className="text-destructive">
            <Trash2 className="mr-1 size-4" />
            Clear
          </Button>
        )}
      </header>

      {favorites.length === 0 ? (
        <Card className="flex flex-col items-center gap-3 py-14 text-center">
          <div className="flex size-14 items-center justify-center rounded-full bg-primary/10">
            <Star className="size-7 text-primary" />
          </div>
          <p className="text-lg font-semibold">No favorites yet</p>
          <p className="max-w-xs text-sm text-muted-foreground">
            Tap the star on any translation or lesson to save it here.
          </p>
          <Link href="/translator" className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-primary">
            Go to Translator <ArrowRight className="size-4" />
          </Link>
        </Card>
      ) : (
        <ul className="flex flex-col gap-3">
          {favorites.map((f) => (
            <li key={f.id}>
              <Card className="animate-fade-in-up p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">{f.en}</p>
                    <p className="mt-1 font-hanifi text-2xl leading-relaxed text-primary" dir="rtl">
                      {f.hanifi}
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground">{f.roman}</p>
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <SpeakButton text={f.en} compact />
                    <button
                      type="button"
                      onClick={() => remove(f.id)}
                      aria-label="Remove favorite"
                      className="flex size-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-destructive"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
