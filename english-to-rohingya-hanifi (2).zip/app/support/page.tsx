'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Card } from '@/components/ui/card'
import { ChevronDown, LifeBuoy, BookOpen, Mic, Languages, Star } from 'lucide-react'
import { cn } from '@/lib/utils'

const faqs = [
  {
    q: 'How do I translate between English and Rohingya?',
    a: 'Open the Translator, type your text, and tap Translate. Use the swap button to switch direction between English → Rohingya and Rohingya → English.',
  },
  {
    q: 'Why can I hear English but not Rohingya out loud?',
    a: 'Your device has a built-in English voice. Most phones do not include a Rohingya voice yet, so the Listen button reads the English side. The Hanifi script is always shown on screen.',
  },
  {
    q: 'Voice input is not working. What can I do?',
    a: 'Voice input (microphone) needs a supported browser such as Chrome on Android, plus microphone permission. If your device does not support it, you can still type normally.',
  },
  {
    q: 'How do lessons work?',
    a: 'Each lesson shows English with its Rohingya Hanifi form. Use Next and Previous to move through the cards, tap Listen to hear the English, and watch the progress bar fill as you learn.',
  },
  {
    q: 'Do my favorites and history save?',
    a: 'Yes. Favorites and history are stored on your device so they stay after you close the app. You can clear them anytime from their pages.',
  },
]

const quickLinks = [
  { href: '/translator', label: 'Translator', icon: Languages },
  { href: '/lessons', label: 'Lessons', icon: BookOpen },
  { href: '/voice-practice', label: 'Voice Practice', icon: Mic },
  { href: '/favorites', label: 'Favorites', icon: Star },
]

export default function SupportPage() {
  const [open, setOpen] = useState<number | null>(0)

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <header className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Support</h1>
        <p className="mt-1 text-muted-foreground">Help and answers to common questions.</p>
      </header>

      <Card className="mb-4 flex items-center gap-4 bg-primary/10 p-5">
        <div className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-primary">
          <LifeBuoy className="size-6" />
        </div>
        <div>
          <p className="font-semibold">Need a hand?</p>
          <p className="text-sm text-muted-foreground">
            Browse the FAQs below, or jump to a feature to get started.
          </p>
        </div>
      </Card>

      <div className="mb-6 grid grid-cols-2 gap-3">
        {quickLinks.map((l) => (
          <Link key={l.href} href={l.href}>
            <Card className="flex items-center gap-3 p-4 transition-transform active:scale-[0.98]">
              <l.icon className="size-5 text-primary" />
              <span className="text-sm font-medium">{l.label}</span>
            </Card>
          </Link>
        ))}
      </div>

      <h2 className="mb-3 text-lg font-semibold">Frequently asked questions</h2>
      <ul className="flex flex-col gap-2.5">
        {faqs.map((f, i) => {
          const isOpen = open === i
          return (
            <li key={i}>
              <Card className="overflow-hidden">
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-3 p-4 text-left"
                  aria-expanded={isOpen}
                >
                  <span className="font-medium">{f.q}</span>
                  <ChevronDown
                    className={cn('size-5 shrink-0 text-muted-foreground transition-transform', isOpen && 'rotate-180')}
                  />
                </button>
                <div
                  className={cn(
                    'grid transition-all duration-300',
                    isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0',
                  )}
                >
                  <div className="overflow-hidden">
                    <p className="px-4 pb-4 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
                  </div>
                </div>
              </Card>
            </li>
          )
        })}
      </ul>

      <p className="mt-8 text-center text-sm text-muted-foreground">
        English to Rohingya Hanifi · by Arakani Gamer
      </p>
    </div>
  )
}
