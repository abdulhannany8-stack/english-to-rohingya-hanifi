'use client'

import Link from 'next/link'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { SpeakButton } from '@/components/speak-button'
import { useHistory, useFavorites } from '@/lib/storage'
import { History as HistoryIcon, Trash2, Star, ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'

function timeAgo(ts: number) {
  const diff = Date.now() - ts
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  const days = Math.floor(hrs / 24)
  return `${days}d ago`
}

export default function HistoryPage() {
  const { history, remove, clear } = useHistory()
  const { toggle, isFavorite } = useFavorites()

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">History</h1>
          <p className="mt-1 text-muted-foreground">Your recent translations.</p>
        </div>
        {history.length > 0 && (
          <Button variant="ghost" size="sm" onClick={clear} className="text-destructive">
            <Trash2 className="mr-1 size-4" />
            Clear
          </Button>
        )}
      </header>

      {history.length === 0 ? (
        <Card className="flex flex-col items-center gap-3 py-14 text-center">
          <div className="flex size-14 items-center justify-center rounded-full bg-primary/10">
            <HistoryIcon className="size-7 text-primary" />
          </div>
          <p className="text-lg font-semibold">No history yet</p>
          <p className="max-w-xs text-sm text-muted-foreground">
            Translations you make will appear here automatically.
          </p>
          <Link href="/translator" className="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-primary">
            Start translating <ArrowRight className="size-4" />
          </Link>
        </Card>
      ) : (
        <ul className="flex flex-col gap-3">
          {history.map((h) => {
            const fav = isFavorite(h.en, h.direction)
            return (
              <li key={h.id}>
                <Card className="animate-fade-in-up p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground">
                      {h.direction === 'en-rh' ? 'English → Rohingya' : 'Rohingya → English'}
                    </span>
                    <span className="text-xs text-muted-foreground">{timeAgo(h.createdAt)}</span>
                  </div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold">{h.en}</p>
                      <p className="mt-1 font-hanifi text-2xl leading-relaxed text-primary" dir="rtl">
                        {h.hanifi}
                      </p>
                      <p className="mt-1 text-sm text-muted-foreground">{h.roman}</p>
                    </div>
                    <div className="flex flex-col items-center gap-2">
                      <SpeakButton text={h.en} compact />
                      <button
                        type="button"
                        onClick={() => toggle({ en: h.en, roman: h.roman, hanifi: h.hanifi, direction: h.direction })}
                        aria-label={fav ? 'Remove from favorites' : 'Add to favorites'}
                        className="flex size-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-primary"
                      >
                        <Star className={cn('size-4', fav && 'fill-accent text-accent')} />
                      </button>
                      <button
                        type="button"
                        onClick={() => remove(h.id)}
                        aria-label="Delete from history"
                        className="flex size-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-destructive"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </div>
                </Card>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
