import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Noto_Sans, Noto_Sans_Hanifi_Rohingya } from 'next/font/google'
import { SettingsProvider } from '@/components/providers/settings-provider'
import { AppShell } from '@/components/app-shell'
import './globals.css'

const notoSans = Noto_Sans({
  subsets: ['latin'],
  variable: '--font-noto-sans',
  display: 'swap',
})

const hanifi = Noto_Sans_Hanifi_Rohingya({
  subsets: ['rohingya'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-hanifi-rohingya',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'English to Rohingya Hanifi',
  description:
    'Learn English Through Rohingya Hanifi — translation, lessons, voice practice and more. Created by Arakani Gamer.',
  generator: 'v0.app',
  applicationName: 'English to Rohingya Hanifi',
  manifest: '/manifest.webmanifest',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'RohingyaHanifi',
  },
  icons: {
    icon: '/icon.png',
    apple: '/icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#0e7c86' },
    { media: '(prefers-color-scheme: dark)', color: '#0b2027' },
  ],
}

const themeScript = `
(function() {
  try {
    var s = JSON.parse(localStorage.getItem('erh-settings') || '{}');
    var theme = s.theme || 'system';
    var isDark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    var root = document.documentElement;
    root.classList.toggle('dark', isDark);
    root.classList.toggle('light', !isDark);
    if (s.textScale) root.style.setProperty('--text-scale', String(s.textScale));
  } catch (e) {}
})();
`

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="en"
      className={`${notoSans.variable} ${hanifi.variable} bg-background`}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="font-sans antialiased">
        <SettingsProvider>
          <AppShell>{children}</AppShell>
        </SettingsProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
