import Image from 'next/image'
import { Card } from '@/components/ui/card'
import { Languages, BookOpen, Mic, Heart } from 'lucide-react'

const highlights = [
  { icon: Languages, label: 'Two-way translation' },
  { icon: BookOpen, label: '10 learning lessons' },
  { icon: Mic, label: 'Voice practice' },
  { icon: Heart, label: 'Favorites & history' },
]

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <header className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">About Me</h1>
      </header>

      <Card className="animate-fade-in-up overflow-hidden">
        <div className="flex flex-col items-center gap-4 bg-primary/10 px-6 py-8 text-center">
          <div className="overflow-hidden rounded-3xl shadow-lg">
            <Image
              src="/icon-512.png"
              alt="English to Rohingya Hanifi app icon"
              width={96}
              height={96}
              className="size-24"
            />
          </div>
          <div>
            <p className="text-xl font-bold">English to Rohingya Hanifi</p>
            <p className="mt-1 text-sm text-muted-foreground">Learn English Through Rohingya Hanifi</p>
          </div>
        </div>

        <div className="px-6 py-6">
          <p className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Created by</p>
          <p className="mt-1 text-2xl font-bold text-primary">Arakani Gamer</p>

          <p className="mt-5 text-pretty text-lg leading-relaxed text-foreground">
            English to Rohingya Hanifi is created to help Rohingya users learn English easily through their own language
            and writing system.
          </p>
        </div>
      </Card>

      <div className="mt-4 grid grid-cols-2 gap-3">
        {highlights.map((h) => (
          <Card key={h.label} className="flex items-center gap-3 p-4">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <h.icon className="size-5" />
            </div>
            <span className="text-sm font-medium leading-tight">{h.label}</span>
          </Card>
        ))}
      </div>

      <p className="mt-6 text-center text-xs text-muted-foreground">
        Rohingya Hanifi text uses the official Hanifi Rohingya Unicode script.
      </p>
    </div>
  )
}
