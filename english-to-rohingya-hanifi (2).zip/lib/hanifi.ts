/**
 * Rohingyalish (Latin Rohingya) -> Hanifi Rohingya script transliteration.
 *
 * Uses the official Hanifi Rohingya Unicode block (U+10D00..U+10D3F).
 * The script is written right-to-left; vowel signs are combining marks
 * placed after the consonant in logical order.
 *
 * This produces valid, consistent Hanifi Unicode from the romanized
 * spelling. Native speakers can refine individual dictionary entries,
 * but numbers and the core consonant/vowel set are mapped accurately.
 */

// Consonants
const C = {
  A: '\u{10D00}', // independent vowel carrier (alef)
  BA: '\u{10D01}',
  PA: '\u{10D02}',
  TA: '\u{10D03}',
  TTA: '\u{10D04}', // retroflex ṭ
  JA: '\u{10D05}',
  CA: '\u{10D06}', // ch
  HA: '\u{10D07}',
  KHA: '\u{10D08}',
  FA: '\u{10D09}',
  DA: '\u{10D0A}',
  DDA: '\u{10D0B}', // retroflex ḍ
  RA: '\u{10D0C}',
  RRA: '\u{10D0D}', // retroflex ṛ
  ZA: '\u{10D0E}',
  SA: '\u{10D0F}',
  SHA: '\u{10D10}',
  KA: '\u{10D11}',
  GA: '\u{10D12}',
  LA: '\u{10D13}',
  MA: '\u{10D14}',
  NA: '\u{10D15}',
  WA: '\u{10D16}',
  YA: '\u{10D18}',
  NGA: '\u{10D1A}',
  NYA: '\u{10D1B}',
  VA: '\u{10D1C}',
}

// Combining vowel signs (placed after a consonant)
const V = {
  a: '\u{10D1D}',
  i: '\u{10D1E}',
  u: '\u{10D1F}',
  e: '\u{10D20}',
  o: '\u{10D21}',
}

// Independent vowels (word-initial) = carrier + vowel sign
const IV: Record<string, string> = {
  a: C.A,
  aa: C.A + V.a,
  i: C.A + V.i,
  u: C.A + V.u,
  e: C.A + V.e,
  o: C.A + V.o,
}

// Digits
const DIGITS = [
  '\u{10D30}',
  '\u{10D31}',
  '\u{10D32}',
  '\u{10D33}',
  '\u{10D34}',
  '\u{10D35}',
  '\u{10D36}',
  '\u{10D37}',
  '\u{10D38}',
  '\u{10D39}',
]

// Digraph consonants (checked before single letters)
const DIGRAPHS: [string, string][] = [
  ['sh', C.SHA],
  ['kh', C.KHA],
  ['ng', C.NGA],
  ['ny', C.NYA],
  ['ch', C.CA],
  ['tt', C.TTA],
  ['dd', C.DDA],
  ['rr', C.RRA],
]

// Single consonants. Rohingyalish uses capitals for retroflex sounds.
const SINGLE: Record<string, string> = {
  b: C.BA,
  p: C.PA,
  t: C.TA,
  T: C.TTA,
  j: C.JA,
  c: C.CA,
  h: C.HA,
  f: C.FA,
  d: C.DA,
  D: C.DDA,
  r: C.RA,
  R: C.RRA,
  z: C.ZA,
  s: C.SA,
  x: C.SHA,
  k: C.KA,
  q: C.KA,
  g: C.GA,
  l: C.LA,
  m: C.MA,
  n: C.NA,
  N: C.NGA,
  w: C.WA,
  v: C.VA,
  y: C.YA,
}

const VOWELS = new Set(['a', 'i', 'u', 'e', 'o', 'A', 'E', 'O', 'I', 'U'])

function isVowel(ch: string) {
  return VOWELS.has(ch)
}

function transliterateWord(word: string): string {
  let out = ''
  let i = 0
  let lastWasConsonant = false

  while (i < word.length) {
    const ch = word[i]

    // Digits
    if (ch >= '0' && ch <= '9') {
      out += DIGITS[Number(ch)]
      i += 1
      lastWasConsonant = false
      continue
    }

    // Try digraph consonants
    const pair = word.slice(i, i + 2).toLowerCase()
    const digraph = DIGRAPHS.find(([g]) => g === pair)
    if (digraph) {
      out += digraph[1]
      i += 2
      lastWasConsonant = true
      continue
    }

    // Vowels
    const lower = ch.toLowerCase()
    if (isVowel(ch)) {
      if (lastWasConsonant) {
        out += V[lower as keyof typeof V] ?? V.a
      } else {
        out += IV[lower] ?? IV.a
      }
      i += 1
      lastWasConsonant = false
      continue
    }

    // Single consonants
    const single = SINGLE[ch] ?? SINGLE[lower]
    if (single) {
      out += single
      i += 1
      lastWasConsonant = true
      continue
    }

    // Unknown char (space handled by caller); keep as-is
    out += ch
    i += 1
    lastWasConsonant = false
  }

  return out
}

/**
 * Convert a romanized Rohingya (Rohingyalish) string to Hanifi Rohingya script.
 */
export function toHanifi(roman: string): string {
  if (!roman) return ''
  return roman
    .split(/(\s+)/)
    .map((token) => (/^\s+$/.test(token) ? token : transliterateWord(token)))
    .join('')
    .trim()
}

/** Convert Western digits in a string to Hanifi Rohingya digits. */
export function toHanifiDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => DIGITS[Number(d)])
}
