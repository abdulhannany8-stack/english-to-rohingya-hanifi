import { toHanifi } from '@/lib/hanifi'
import { lessons } from '@/lib/data/lessons'

export type Entry = {
  en: string
  roman: string
  hanifi: string
}

// Build a base dictionary from all lesson phrases.
function buildBase(): Entry[] {
  const map = new Map<string, Entry>()
  for (const lesson of lessons) {
    for (const p of lesson.phrases) {
      const key = p.en.toLowerCase()
      if (!map.has(key) && !p.en.includes('—')) {
        map.set(key, {
          en: p.en,
          roman: p.roman,
          hanifi: p.hanifi ?? toHanifi(p.roman),
        })
      }
    }
  }
  return Array.from(map.values())
}

// Extra high-frequency words for the offline dictionary.
const extra: { en: string; roman: string }[] = [
  { en: 'yes', roman: 'oó' },
  { en: 'no', roman: 'no' },
  { en: 'good', roman: 'bala' },
  { en: 'bad', roman: 'kharap' },
  { en: 'big', roman: 'boro' },
  { en: 'small', roman: 'suru' },
  { en: 'today', roman: 'aiz' },
  { en: 'tomorrow', roman: 'hailla' },
  { en: 'yesterday', roman: 'giakal' },
  { en: 'now', roman: 'ekhon' },
  { en: 'day', roman: 'din' },
  { en: 'night', roman: 'rait' },
  { en: 'friend', roman: 'dusto' },
  { en: 'love', roman: 'muhabbat' },
  { en: 'happy', roman: 'khushi' },
  { en: 'sad', roman: 'dukh' },
  { en: 'money', roman: 'toka' },
  { en: 'time', roman: 'time' },
  { en: 'name', roman: 'nam' },
  { en: 'sorry', roman: 'maf goron' },
]

export const dictionary: Entry[] = [
  ...buildBase(),
  ...extra.map((e) => ({ ...e, hanifi: toHanifi(e.roman) })),
]

const byEnglish = new Map(dictionary.map((e) => [e.en.toLowerCase(), e]))

/**
 * Offline lookup. Returns an entry if the whole phrase matches a known word.
 */
export function localLookup(text: string): Entry | null {
  const key = text.trim().toLowerCase().replace(/[.?!]$/, '')
  return byEnglish.get(key) ?? null
}

// Word of the Day pool
export const wordOfTheDayPool: Entry[] = dictionary.filter(
  (e) => !e.en.includes('?') && e.en.split(' ').length <= 3,
)

/** Deterministic Word of the Day based on the date. */
export function wordOfTheDay(date = new Date()): Entry {
  const start = new Date(date.getFullYear(), 0, 0)
  const diff = date.getTime() - start.getTime()
  const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24))
  const index = dayOfYear % wordOfTheDayPool.length
  return wordOfTheDayPool[index]
}
