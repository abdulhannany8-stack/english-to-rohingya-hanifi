import { toHanifi, toHanifiDigits } from '@/lib/hanifi'

export type Phrase = {
  en: string
  roman: string
  hanifi?: string
}

export type Lesson = {
  id: string
  title: string
  icon: string
  description: string
  phrases: Phrase[]
}

/** Resolve the Hanifi form for a phrase (explicit override or transliterated). */
export function hanifiOf(p: Phrase): string {
  return p.hanifi ?? toHanifi(p.roman)
}

const englishNumberWords: Record<number, string> = {
  0: 'Zero',
  1: 'One',
  2: 'Two',
  3: 'Three',
  4: 'Four',
  5: 'Five',
  6: 'Six',
  7: 'Seven',
  8: 'Eight',
  9: 'Nine',
  10: 'Ten',
  11: 'Eleven',
  12: 'Twelve',
  13: 'Thirteen',
  14: 'Fourteen',
  15: 'Fifteen',
  16: 'Sixteen',
  17: 'Seventeen',
  18: 'Eighteen',
  19: 'Nineteen',
  20: 'Twenty',
  30: 'Thirty',
  40: 'Forty',
  50: 'Fifty',
  60: 'Sixty',
  70: 'Seventy',
  80: 'Eighty',
  90: 'Ninety',
  100: 'One Hundred',
}

function englishFor(n: number): string {
  if (englishNumberWords[n]) return englishNumberWords[n]
  const tens = Math.floor(n / 10) * 10
  const ones = n % 10
  return `${englishNumberWords[tens]}-${englishNumberWords[ones]}`
}

// Common Rohingya (Rohingyalish) number words 1-10
const romanNumber: Record<number, string> = {
  1: 'ek',
  2: 'dui',
  3: 'tin',
  4: 'sair',
  5: 'fañs',
  6: 'so',
  7: 'sat',
  8: 'aat',
  9: 'noo',
  10: 'dosh',
}

function buildNumbers(): Phrase[] {
  const out: Phrase[] = []
  for (let n = 1; n <= 100; n++) {
    const roman = romanNumber[n] ?? String(n)
    out.push({
      en: `${n} — ${englishFor(n)}`,
      roman,
      // Always show the accurate Hanifi numeral for the number
      hanifi: toHanifiDigits(n) + (romanNumber[n] ? ` (${toHanifi(roman)})` : ''),
    })
  }
  return out
}

export const lessons: Lesson[] = [
  {
    id: 'greetings',
    title: 'Greetings',
    icon: 'HandHeart',
    description: 'Say hello, goodbye and be polite.',
    phrases: [
      { en: 'Hello', roman: 'Assalamu alaikum' },
      { en: 'Peace be upon you (reply)', roman: 'Walaikum assalam' },
      { en: 'Good morning', roman: 'Bihanor salam' },
      { en: 'How are you?', roman: 'Kemon aso?' },
      { en: 'I am fine', roman: 'Ami bala asi' },
      { en: 'Thank you', roman: 'Shukuria' },
      { en: 'You are welcome', roman: 'Khoshi hoiye' },
      { en: 'Please', roman: 'Doya gori' },
      { en: 'Excuse me', roman: 'Maf goron' },
      { en: 'Goodbye', roman: 'Khoda hafez' },
    ],
  },
  {
    id: 'introduction',
    title: 'Introduction',
    icon: 'UserRound',
    description: 'Introduce yourself and others.',
    phrases: [
      { en: 'What is your name?', roman: 'Tuñar nam kiye?' },
      { en: 'My name is Ali', roman: 'Añr nam Ali' },
      { en: 'Nice to meet you', roman: 'Tuáñre mili khoshi hoilam' },
      { en: 'Where are you from?', roman: 'Tuñi hoódtu aiso?' },
      { en: 'I am from Arakan', roman: 'Ami Arakan tu' },
      { en: 'How old are you?', roman: 'Tuñar boyoc hoto?' },
      { en: 'I am a student', roman: 'Ami ekjon talibul elm' },
      { en: 'I speak a little English', roman: 'Ami tuáñ English hoiparo' },
      { en: 'I do not understand', roman: 'Ami buji no faari' },
      { en: 'Can you help me?', roman: 'Tuñi añre modot goribba ne?' },
    ],
  },
  {
    id: 'numbers',
    title: 'Numbers 1–100',
    icon: 'Hash',
    description: 'Count from one to one hundred.',
    phrases: buildNumbers(),
  },
  {
    id: 'family',
    title: 'Family',
    icon: 'Users',
    description: 'Words for family members.',
    phrases: [
      { en: 'Family', roman: 'Ghor manush' },
      { en: 'Father', roman: 'Baf' },
      { en: 'Mother', roman: 'Ma' },
      { en: 'Brother', roman: 'Bái' },
      { en: 'Sister', roman: 'Bôin' },
      { en: 'Son', roman: 'Fua' },
      { en: 'Daughter', roman: 'Maiya' },
      { en: 'Grandfather', roman: 'Dada' },
      { en: 'Grandmother', roman: 'Dadi' },
      { en: 'Husband', roman: 'Zamai' },
      { en: 'Wife', roman: 'Bibi' },
      { en: 'Child', roman: 'Bacha' },
    ],
  },
  {
    id: 'food',
    title: 'Food',
    icon: 'Utensils',
    description: 'Talk about food and eating.',
    phrases: [
      { en: 'Food', roman: 'Hana' },
      { en: 'Water', roman: 'Faani' },
      { en: 'Rice', roman: 'Bat' },
      { en: 'Bread', roman: 'Ruti' },
      { en: 'Fish', roman: 'Maas' },
      { en: 'Meat', roman: 'Gusto' },
      { en: 'Milk', roman: 'Dud' },
      { en: 'Tea', roman: 'Sa' },
      { en: 'I am hungry', roman: 'Añr khida lagce' },
      { en: 'I am thirsty', roman: 'Añr faani lagce' },
      { en: 'It is delicious', roman: 'Ye bala lage' },
      { en: 'I want to eat', roman: 'Ami haite saai' },
    ],
  },
  {
    id: 'school',
    title: 'School',
    icon: 'GraduationCap',
    description: 'Words used at school.',
    phrases: [
      { en: 'School', roman: 'Iskul' },
      { en: 'Teacher', roman: 'Ustad' },
      { en: 'Student', roman: 'Talibul elm' },
      { en: 'Book', roman: 'Kitab' },
      { en: 'Pen', roman: 'Kolom' },
      { en: 'Paper', roman: 'Kagoz' },
      { en: 'To read', roman: 'Fora' },
      { en: 'To write', roman: 'Lekha' },
      { en: 'Lesson', roman: 'Sobok' },
      { en: 'Question', roman: 'Sowal' },
      { en: 'Answer', roman: 'Jowab' },
    ],
  },
  {
    id: 'home',
    title: 'Home',
    icon: 'House',
    description: 'Things around the house.',
    phrases: [
      { en: 'Home', roman: 'Ghor' },
      { en: 'Door', roman: 'Duar' },
      { en: 'Window', roman: 'Janala' },
      { en: 'Room', roman: 'Kamra' },
      { en: 'Bed', roman: 'Bisana' },
      { en: 'Kitchen', roman: 'Solha' },
      { en: 'Chair', roman: 'Sowki' },
      { en: 'Table', roman: 'Tebul' },
      { en: 'Light', roman: 'Batti' },
      { en: 'Come inside', roman: 'Bútore au' },
      { en: 'Sit down', roman: 'Boi zoo' },
    ],
  },
  {
    id: 'daily',
    title: 'Daily Activities',
    icon: 'Sun',
    description: 'Everyday actions and routines.',
    phrases: [
      { en: 'To wake up', roman: 'Uti zoon' },
      { en: 'To sleep', roman: 'Ghum zoon' },
      { en: 'To eat', roman: 'Hana hoon' },
      { en: 'To drink', roman: 'Faani hoon' },
      { en: 'To go', roman: 'Zoon' },
      { en: 'To come', roman: 'Aon' },
      { en: 'To work', roman: 'Kam goron' },
      { en: 'To pray', roman: 'Namaz foron' },
      { en: 'To wash', roman: 'Doon' },
      { en: 'To walk', roman: 'Añte zoon' },
    ],
  },
  {
    id: 'questions',
    title: 'Common Questions',
    icon: 'CircleHelp',
    description: 'Ask the basic question words.',
    phrases: [
      { en: 'What?', roman: 'Kiye?' },
      { en: 'Who?', roman: 'Hon?' },
      { en: 'Where?', roman: 'Hoóde?' },
      { en: 'When?', roman: 'Hoçé?' },
      { en: 'Why?', roman: 'Kiyollay?' },
      { en: 'How?', roman: 'Kemne?' },
      { en: 'How much?', roman: 'Hoto?' },
      { en: 'Which one?', roman: 'Honnan?' },
      { en: 'Is it far?', roman: 'Duro ne?' },
      { en: 'What time is it?', roman: 'Hoto baze?' },
    ],
  },
  {
    id: 'conversations',
    title: 'Everyday Conversations',
    icon: 'MessagesSquare',
    description: 'Useful full sentences for daily talk.',
    phrases: [
      { en: 'How much is this?', roman: 'Yian hoto daam?' },
      { en: 'It is too expensive', roman: 'Yian bicí daam' },
      { en: 'Where is the market?', roman: 'Bazar hoóde?' },
      { en: 'I need help', roman: 'Añr modot lage' },
      { en: 'Wait a moment', roman: 'Ekku thako' },
      { en: 'Let us go', roman: 'Solo za' },
      { en: 'I do not know', roman: 'Ami no zani' },
      { en: 'See you again', roman: 'Aró dekha hoibo' },
      { en: 'Take care', roman: 'Bala takio' },
      { en: 'No problem', roman: 'Kono somossa nai' },
    ],
  },
]

export function getLesson(id: string): Lesson | undefined {
  return lessons.find((l) => l.id === id)
}
