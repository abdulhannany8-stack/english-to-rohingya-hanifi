'use client'

/** Text-to-speech for English using the Web Speech API. */
export function speak(text: string, opts?: { rate?: number; lang?: string }) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return false
  }
  try {
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = opts?.lang ?? 'en-US'
    utterance.rate = Math.min(Math.max(opts?.rate ?? 1, 0.5), 2)
    window.speechSynthesis.speak(utterance)
    return true
  } catch {
    return false
  }
}

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel()
  }
}

export function isTTSSupported() {
  return typeof window !== 'undefined' && 'speechSynthesis' in window
}

// --- Speech recognition (speech-to-text) ---

type SpeechRecognitionLike = {
  lang: string
  continuous: boolean
  interimResults: boolean
  start: () => void
  stop: () => void
  onresult: ((event: any) => void) | null
  onerror: ((event: any) => void) | null
  onend: (() => void) | null
}

function getRecognitionCtor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === 'undefined') return null
  return (
    (window as any).SpeechRecognition ||
    (window as any).webkitSpeechRecognition ||
    null
  )
}

export function isSTTSupported() {
  return getRecognitionCtor() !== null
}

/**
 * Start listening. Returns a stop() function, or null if unsupported.
 */
export function listen(
  opts: {
    lang?: string
    onResult: (transcript: string) => void
    onError?: (error: string) => void
    onEnd?: () => void
  },
): (() => void) | null {
  const Ctor = getRecognitionCtor()
  if (!Ctor) return null
  const recognition = new Ctor()
  recognition.lang = opts.lang ?? 'en-US'
  recognition.continuous = false
  recognition.interimResults = false

  recognition.onresult = (event: any) => {
    const transcript = Array.from(event.results)
      .map((r: any) => r[0].transcript)
      .join(' ')
    opts.onResult(transcript)
  }
  recognition.onerror = (event: any) => {
    opts.onError?.(event.error ?? 'unknown')
  }
  recognition.onend = () => {
    opts.onEnd?.()
  }

  recognition.start()
  return () => recognition.stop()
}
