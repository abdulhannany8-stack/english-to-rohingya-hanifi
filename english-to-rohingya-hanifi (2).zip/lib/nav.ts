import type { LucideIcon } from 'lucide-react'
import {
  Home,
  Languages,
  BookOpen,
  Mic,
  CalendarDays,
  Star,
  History,
  UserRound,
  Settings,
  LifeBuoy,
} from 'lucide-react'

export type NavItem = {
  label: string
  href: string
  icon: LucideIcon
}

export const menuItems: NavItem[] = [
  { label: 'Home', href: '/', icon: Home },
  { label: 'Translator', href: '/translator', icon: Languages },
  { label: 'Lessons', href: '/lessons', icon: BookOpen },
  { label: 'Voice Practice', href: '/voice', icon: Mic },
  { label: 'Word of the Day', href: '/word', icon: CalendarDays },
  { label: 'Favorites', href: '/favorites', icon: Star },
  { label: 'History', href: '/history', icon: History },
  { label: 'About Me', href: '/about', icon: UserRound },
  { label: 'Settings', href: '/settings', icon: Settings },
  { label: 'Support', href: '/support', icon: LifeBuoy },
]

export const bottomNav: NavItem[] = [
  { label: 'Home', href: '/', icon: Home },
  { label: 'Translate', href: '/translator', icon: Languages },
  { label: 'Lessons', href: '/lessons', icon: BookOpen },
  { label: 'Voice', href: '/voice', icon: Mic },
]
