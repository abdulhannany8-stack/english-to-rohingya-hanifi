'use client'

import { useCallback, useEffect, useState } from 'react'

export type TranslationRecord = {
  id: string
  en: string
  roman: string
  hanifi: string
  direction: 'en-rh' | 'rh-en'
  createdAt: number
}

const HISTORY_KEY = 'erh-history'
const FAVORITES_KEY = 'erh-favorites'

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

function write<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
    // Notify other hook instances in the same tab
    window.dispatchEvent(new CustomEvent('erh-storage', { detail: key }))
  } catch {
    // ignore
  }
}

function useLocalList(key: string) {
  const [items, setItems] = useState<TranslationRecord[]>([])

  useEffect(() => {
    setItems(read<TranslationRecord[]>(key, []))
    const sync = (e: Event) => {
      const detail = (e as CustomEvent).detail
      if (detail === key || e.type === 'storage') {
        setItems(read<TranslationRecord[]>(key, []))
      }
    }
    window.addEventListener('erh-storage', sync)
    window.addEventListener('storage', sync)
    return () => {
      window.removeEventListener('erh-storage', sync)
      window.removeEventListener('storage', sync)
    }
  }, [key])

  return [items, setItems] as const
}

export function useHistory() {
  const [history, setHistory] = useLocalList(HISTORY_KEY)

  const add = useCallback((record: Omit<TranslationRecord, 'id' | 'createdAt'>) => {
    const next: TranslationRecord = {
      ...record,
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      createdAt: Date.now(),
    }
    const current = read<TranslationRecord[]>(HISTORY_KEY, [])
    // Avoid consecutive duplicates
    if (current[0]?.en === next.en && current[0]?.direction === next.direction) {
      return
    }
    const updated = [next, ...current].slice(0, 100)
    write(HISTORY_KEY, updated)
    setHistory(updated)
  }, [setHistory])

  const remove = useCallback((id: string) => {
    const updated = read<TranslationRecord[]>(HISTORY_KEY, []).filter((r) => r.id !== id)
    write(HISTORY_KEY, updated)
    setHistory(updated)
  }, [setHistory])

  const clear = useCallback(() => {
    write(HISTORY_KEY, [])
    setHistory([])
  }, [setHistory])

  return { history, add, remove, clear }
}

export function useFavorites() {
  const [favorites, setFavorites] = useLocalList(FAVORITES_KEY)

  const isFavorite = useCallback(
    (en: string, direction: TranslationRecord['direction']) =>
      favorites.some((f) => f.en === en && f.direction === direction),
    [favorites],
  )

  const toggle = useCallback(
    (record: Omit<TranslationRecord, 'id' | 'createdAt'>) => {
      const current = read<TranslationRecord[]>(FAVORITES_KEY, [])
      const exists = current.find(
        (f) => f.en === record.en && f.direction === record.direction,
      )
      let updated: TranslationRecord[]
      if (exists) {
        updated = current.filter((f) => f.id !== exists.id)
      } else {
        updated = [
          {
            ...record,
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            createdAt: Date.now(),
          },
          ...current,
        ]
      }
      write(FAVORITES_KEY, updated)
      setFavorites(updated)
    },
    [setFavorites],
  )

  const remove = useCallback((id: string) => {
    const updated = read<TranslationRecord[]>(FAVORITES_KEY, []).filter((r) => r.id !== id)
    write(FAVORITES_KEY, updated)
    setFavorites(updated)
  }, [setFavorites])

  const clear = useCallback(() => {
    write(FAVORITES_KEY, [])
    setFavorites([])
  }, [setFavorites])

  return { favorites, isFavorite, toggle, remove, clear }
}
